document.addEventListener("DOMContentLoaded", () => {
    fetch('/api/jobs')
        .then(response => response.json())
        .then(jobs => console.log(jobs))
        .catch(error => console.error('Error fetching jobs:', error));
});