const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());

const jobs = [
    { id: 1, title: "Software Engineer", company: "ABC Corp" },
    { id: 2, title: "Data Scientist", company: "XYZ Inc." }
];

app.get('/api/jobs', (req, res) => {
    res.json(jobs);
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));